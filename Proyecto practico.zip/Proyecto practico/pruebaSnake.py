from ejecutador import Juego

# Para jugar Tetris
# juego_tetris = Juego("arbol_tetris.ast", "tetris")
# juego_tetris.run_game_tetris()

# Para jugar Snake
juego_snake = Juego("arbol_snake.ast", "snake")
juego_snake.run_game_snake()