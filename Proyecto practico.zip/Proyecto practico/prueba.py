import traceback
import os  # <-- 1. Importamos el módulo OS
from ejecutador import Juego

# 2. Obtenemos la ruta absoluta de la CARPETA donde está este script 'jugar.py'
base_dir = os.path.dirname(os.path.abspath(__file__))

# 3. Creamos la ruta completa y correcta para el archivo .ast
ruta_ast = os.path.join(base_dir, "arbol_tetris.ast")

try:
    # 4. Usamos la nueva ruta_ast que SIEMPRE será correcta
    juego_tetris = Juego(ruta_ast, "tetris")
    juego_tetris.run_game_tetris()

except Exception as e:
    print("\n" + "="*30)
    print("Ha ocurrido un error inesperado:")
    print(f"ERROR: {e}")
    print("\n--- DETALLES ---")
    traceback.print_exc()
    print("="*30)

finally:
    input("\nPresiona Enter para salir.")